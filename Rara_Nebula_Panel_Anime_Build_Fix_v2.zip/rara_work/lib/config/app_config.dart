/// URL backend API Anda. Set melalui --dart-define saat build.
/// Contoh: flutter run --dart-define=API_BASE_URL=https://api.example.com
class AppConfig {
  static const apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://YOUR-BACKEND-DOMAIN.example',
  );

  static bool get isConfigured =>
      apiBaseUrl.startsWith('https://') &&
      !apiBaseUrl.contains('YOUR-BACKEND-DOMAIN');
}
