import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RaraNebulaApp());
}

class RaraNebulaApp extends StatefulWidget {
  const RaraNebulaApp({super.key});

  @override
  State<RaraNebulaApp> createState() => RaraNebulaAppState();

  static RaraNebulaAppState of(BuildContext context) =>
      context.findAncestorStateOfType<RaraNebulaAppState>()!;
}

class RaraNebulaAppState extends State<RaraNebulaApp> {
  ThemeMode _themeMode = ThemeMode.dark;

  void setTheme(ThemeMode mode) => setState(() => _themeMode = mode);

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF0A0714);
    const panel = Color(0xFF19112B);
    const purple = Color(0xFFBB86FC);
    final dark = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(
        primary: purple,
        secondary: Color(0xFFE0B7FF),
        surface: panel,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF100B1D),
        foregroundColor: Colors.white,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: panel.withValues(alpha: 0.96),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: Color(0xFF3C2A57)),
        ),
        elevation: 0,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF100B1D),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFF493263)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(13),
          borderSide: const BorderSide(color: Color(0xFF493263)),
        ),
      ),
    );
    return MaterialApp(
      title: 'Rara Nebula Panel',
      debugShowCheckedModeBanner: false,
      theme: dark,
      darkTheme: dark,
      themeMode: _themeMode,
      home: const HomeScreen(),
    );
  }
}
