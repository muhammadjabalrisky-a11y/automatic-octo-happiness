class AppUser {
  const AppUser({
    required this.username,
    required this.role,
    required this.token,
  });

  final String username;
  final String role;
  final String token;

  bool get isOwner => role.toLowerCase() == 'owner';

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        username: json['username'] as String? ?? '',
        role: json['role'] as String? ?? 'guest',
        token: json['token'] as String? ?? '',
      );
}
