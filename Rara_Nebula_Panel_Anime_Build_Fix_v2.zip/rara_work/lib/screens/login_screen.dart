import 'package:flutter/material.dart';
import '../models/app_user.dart';
import '../services/api_client.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.api, required this.onLogin});
  final ApiClient api;
  final ValueChanged<AppUser> onLogin;
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  String? _message;

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_form.currentState!.validate()) return;
    setState(() { _busy = true; _message = null; });
    try {
      final data = await widget.api.login(_username.text.trim(), _password.text);
      final raw = data['user'] as Map<String, dynamic>? ?? data;
      final token = data['token'] as String? ?? raw['token'] as String? ?? '';
      final user = AppUser(
        username: raw['username'] as String? ?? _username.text.trim(),
        role: raw['role'] as String? ?? 'guest',
        token: token,
      );
      if (token.isEmpty) throw Exception('Backend tidak mengembalikan token sesi.');
      widget.api.setToken(token);
      widget.onLogin(user);
      if (mounted) {
        setState(() => _message = 'Login berhasil sebagai ${user.role}.');
      }
    } catch (e) {
      if (mounted) setState(() => _message = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Login Akun')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('Masuk ke Nebula',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Akun harus dibuat dan diverifikasi oleh backend.'),
            const SizedBox(height: 22),
            Form(
              key: _form,
              child: Column(
                children: [
                  TextFormField(
                    controller: _username,
                    decoration: const InputDecoration(labelText: 'Username'),
                    validator: (v) => v == null || v.trim().isEmpty ? 'Username wajib diisi' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _password,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Password'),
                    validator: (v) => v == null || v.isEmpty ? 'Password wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: _busy ? null : _login,
                      child: Text(_busy ? 'Memproses...' : 'Login'),
                    ),
                  ),
                ],
              ),
            ),
            if (_message != null) ...[
              const SizedBox(height: 16),
              SelectableText(_message!),
            ],
          ],
        ),
      );
}
