import 'package:flutter/material.dart';
import '../models/app_user.dart';
import '../services/api_client.dart';

class PanelScreen extends StatefulWidget {
  const PanelScreen({super.key, required this.api, required this.user});
  final ApiClient api;
  final AppUser? user;
  @override
  State<PanelScreen> createState() => _PanelScreenState();
}

class _PanelScreenState extends State<PanelScreen> {
  final _form = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _email = TextEditingController();
  int _server = 1;
  String _memory = '1024';
  bool _busy = false;
  String? _result;

  @override
  void dispose() {
    _username.dispose();
    _email.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    if (widget.user == null) {
      setState(() => _result = 'Login dahulu. Role dan kuota akan diverifikasi backend.');
      return;
    }
    if (!_form.currentState!.validate()) return;
    setState(() { _busy = true; _result = null; });
    try {
      final data = await widget.api.createPanel(
        server: _server,
        username: _username.text.trim(),
        email: _email.text.trim(),
        memory: _memory,
      );
      setState(() => _result = data.toString());
    } catch (e) {
      setState(() => _result = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create Panel')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Buat Server Baru',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 18),
            Form(
              key: _form,
              child: Column(
                children: [
                  DropdownButtonFormField<int>(
                    value: _server,
                    decoration: const InputDecoration(labelText: 'Pilih server'),
                    items: List.generate(5, (i) => DropdownMenuItem(
                      value: i + 1, child: Text('Server ${i + 1}'),
                    )),
                    onChanged: (v) => setState(() => _server = v ?? 1),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _username,
                    decoration: const InputDecoration(labelText: 'Username panel'),
                    validator: (v) => v == null || v.trim().length < 3 ? 'Minimal 3 karakter' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(labelText: 'Email pengguna'),
                    validator: (v) => v == null || !v.contains('@') ? 'Masukkan email yang valid' : null,
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: _memory,
                    decoration: const InputDecoration(labelText: 'RAM'),
                    items: [
                      ...List.generate(10, (i) => DropdownMenuItem(
                        value: '${(i + 1) * 1024}', child: Text('${i + 1} GB'),
                      )),
                      const DropdownMenuItem(value: 'unli', child: Text('UNLI (sesuai batas server)')),
                    ],
                    onChanged: (v) => setState(() => _memory = v ?? '1024'),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _create,
                      icon: const Icon(Icons.rocket_launch),
                      label: Text(_busy ? 'Memproses...' : 'Create Panel'),
                    ),
                  ),
                ],
              ),
            ),
            if (_result != null) ...[
              const SizedBox(height: 16),
              Card(child: Padding(
                padding: const EdgeInsets.all(14),
                child: SelectableText(_result!),
              )),
            ],
          ],
        ),
      );
}
