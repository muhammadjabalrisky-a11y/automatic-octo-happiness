import 'package:flutter/material.dart';
import '../models/app_user.dart';
import '../services/api_client.dart';

class AccountsScreen extends StatefulWidget {
  const AccountsScreen({super.key, required this.api, required this.user});
  final ApiClient api;
  final AppUser? user;
  @override
  State<AccountsScreen> createState() => _AccountsScreenState();
}

class _AccountsScreenState extends State<AccountsScreen> {
  final _form = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _password = TextEditingController();
  String _role = 'Reseller Panel';
  bool _busy = false;
  String? _result;
  static const roles = [
    'Reseller Panel', 'Partner Panel', 'Admin Panel', 'TK Panel',
    'CEO Panel', 'Tahta Role Panel', 'Owner Panel'
  ];

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    if (widget.user == null) {
      setState(() => _result = 'Login dahulu. Backend harus memvalidasi hierarki role.');
      return;
    }
    if (!_form.currentState!.validate()) return;
    setState(() { _busy = true; _result = null; });
    try {
      final data = await widget.api.createAccount(
        username: _username.text.trim(),
        password: _password.text,
        role: _role,
      );
      setState(() => _result = data.toString());
    } catch (e) {
      setState(() => _result = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create Account & Role')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Role Management',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Backend wajib membatasi role yang dapat dibuat setiap akun.'),
            const SizedBox(height: 18),
            Form(
              key: _form,
              child: Column(children: [
                TextFormField(controller: _username,
                  decoration: const InputDecoration(labelText: 'Username baru'),
                  validator: (v) => v == null || v.trim().length < 3 ? 'Minimal 3 karakter' : null),
                const SizedBox(height: 12),
                TextFormField(controller: _password, obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password sementara'),
                  validator: (v) => v == null || v.length < 12 ? 'Gunakan minimal 12 karakter' : null),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _role,
                  decoration: const InputDecoration(labelText: 'Role'),
                  items: roles.map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
                  onChanged: (v) => setState(() => _role = v ?? roles.first),
                ),
                const SizedBox(height: 18),
                SizedBox(width: double.infinity, child: FilledButton(
                  onPressed: _busy ? null : _create,
                  child: Text(_busy ? 'Memproses...' : 'Create Account'),
                )),
              ]),
            ),
            if (_result != null) ...[
              const SizedBox(height: 16),
              Card(child: Padding(padding: const EdgeInsets.all(14), child: SelectableText(_result!))),
            ],
          ],
        ),
      );
}
