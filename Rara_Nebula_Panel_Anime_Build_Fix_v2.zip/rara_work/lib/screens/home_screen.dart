import 'package:flutter/material.dart';
import '../main.dart';
import '../models/app_user.dart';
import '../services/api_client.dart';
import 'login_screen.dart';
import 'panel_screen.dart';
import 'admin_screen.dart';
import 'accounts_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiClient _api = ApiClient();
  AppUser? _user;

  void _setUser(AppUser user) {
    setState(() => _user = user);
    _api.setToken(user.token);
  }

  Future<void> _open(Widget page) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = _user;
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('RARA NEBULA', style: TextStyle(fontWeight: FontWeight.w900)),
            Text('PANEL MANAGEMENT',
                style: TextStyle(fontSize: 10, letterSpacing: 2)),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Center(
              child: Chip(label: Text(user?.role.toUpperCase() ?? 'GUEST')),
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              const ListTile(
                leading: Icon(Icons.nightlight_round, color: Color(0xFFBB86FC)),
                title: Text('MENU RARA',
                    style: TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('Explore the cosmos'),
              ),
              _nav(Icons.home_outlined, 'Beranda', () => Navigator.pop(context)),
              _nav(Icons.login, user == null ? 'Login' : 'Ganti akun', () {
                Navigator.pop(context);
                _open(LoginScreen(api: _api, onLogin: _setUser));
              }),
              _nav(Icons.dns_outlined, 'Create Panel', () {
                Navigator.pop(context);
                _open(PanelScreen(api: _api, user: _user));
              }),
              _nav(Icons.admin_panel_settings_outlined, 'Create Admin Panel', () {
                Navigator.pop(context);
                _open(AdminScreen(api: _api, user: _user));
              }),
              _nav(Icons.group_add_outlined, 'Create Account', () {
                Navigator.pop(context);
                _open(AccountsScreen(api: _api, user: _user));
              }),
              _nav(Icons.palette_outlined, 'Tema & Musik', () {
                Navigator.pop(context);
                _open(const SettingsScreen());
              }),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.telegram),
                title: const Text('@rarachutee'),
                onTap: () {},
              ),
              const ListTile(
                leading: Icon(Icons.campaign_outlined),
                title: Text('@testimoni_raraa'),
              ),
            ],
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.8, -0.9),
            radius: 1.2,
            colors: [Color(0xFF34204F), Color(0xFF0A0714)],
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFF51366F)),
                gradient: const LinearGradient(
                  colors: [Color(0xFF261738), Color(0xFF110B1D)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('✦ WELCOME TO THE COSMOS',
                      style: TextStyle(
                          color: Color(0xFFE0B7FF),
                          fontSize: 11,
                          letterSpacing: 2,
                          fontWeight: FontWeight.bold)),
                  SizedBox(height: 12),
                  Text('SELAMAT\\nDATANG, RARA.',
                      style: TextStyle(
                          fontSize: 34,
                          height: 1.05,
                          fontWeight: FontWeight.w900)),
                  SizedBox(height: 12),
                  Text('Kelola panelmu dalam satu tempat.\\nGelap, estetik, dan bertema nebula.',
                      style: TextStyle(color: Color(0xFFC6B8D7), height: 1.5)),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _feature(Icons.dns, 'Create Panel', 'RAM 1–10 GB atau UNLI', () =>
                _open(PanelScreen(api: _api, user: _user))),
            _feature(Icons.shield, 'Create Admin Panel', 'Buat akun admin server', () =>
                _open(AdminScreen(api: _api, user: _user))),
            _feature(Icons.groups, 'Create Account & Role', 'Reseller hingga Owner', () =>
                _open(AccountsScreen(api: _api, user: _user))),
            _feature(Icons.palette, 'Tema & Musik', 'Pengaturan tampilan', () =>
                _open(const SettingsScreen())),
            const SizedBox(height: 12),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  'Keamanan: pembuatan panel memerlukan backend HTTPS yang memvalidasi login dan role. Jangan masukkan PLTA/PLTC ke aplikasi ini.',
                  style: TextStyle(color: Color(0xFFE0B7FF), height: 1.45),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _nav(IconData icon, String label, VoidCallback tap) => ListTile(
        leading: Icon(icon),
        title: Text(label),
        onTap: tap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      );

  Widget _feature(IconData icon, String title, String subtitle, VoidCallback tap) =>
      Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
          leading: CircleAvatar(
            backgroundColor: const Color(0xFF302044),
            child: Icon(icon, color: const Color(0xFFE0B7FF)),
          ),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: tap,
        ),
      );
}
