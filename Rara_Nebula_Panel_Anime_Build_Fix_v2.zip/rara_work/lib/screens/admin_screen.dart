import 'package:flutter/material.dart';
import '../models/app_user.dart';
import '../services/api_client.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key, required this.api, required this.user});
  final ApiClient api;
  final AppUser? user;
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final _form = GlobalKey<FormState>();
  final _username = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  int _server = 1;
  bool _busy = false;
  String? _result;

  @override
  void dispose() {
    _username.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    if (widget.user == null) {
      setState(() => _result = 'Login dahulu. Backend harus memvalidasi izin admin/owner.');
      return;
    }
    if (!_form.currentState!.validate()) return;
    setState(() { _busy = true; _result = null; });
    try {
      final data = await widget.api.createAdmin(
        server: _server,
        username: _username.text.trim(),
        email: _email.text.trim(),
        password: _password.text,
      );
      setState(() => _result = data.toString());
    } catch (e) {
      setState(() => _result = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create Admin Panel')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Admin Server',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 18),
            Form(
              key: _form,
              child: Column(children: [
                DropdownButtonFormField<int>(
                  value: _server,
                  decoration: const InputDecoration(labelText: 'Server'),
                  items: List.generate(5, (i) => DropdownMenuItem(
                    value: i + 1, child: Text('Server ${i + 1}'),
                  )),
                  onChanged: (v) => setState(() => _server = v ?? 1),
                ),
                const SizedBox(height: 12),
                TextFormField(controller: _username,
                  decoration: const InputDecoration(labelText: 'Username'),
                  validator: (v) => v == null || v.trim().length < 3 ? 'Minimal 3 karakter' : null),
                const SizedBox(height: 12),
                TextFormField(controller: _email, keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email'),
                  validator: (v) => v == null || !v.contains('@') ? 'Email tidak valid' : null),
                const SizedBox(height: 12),
                TextFormField(controller: _password, obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password sementara'),
                  validator: (v) => v == null || v.length < 12 ? 'Gunakan minimal 12 karakter' : null),
                const SizedBox(height: 18),
                SizedBox(width: double.infinity, child: FilledButton(
                  onPressed: _busy ? null : _create,
                  child: Text(_busy ? 'Memproses...' : 'Create Admin'),
                )),
              ]),
            ),
            if (_result != null) ...[
              const SizedBox(height: 16),
              Card(child: Padding(padding: const EdgeInsets.all(14), child: SelectableText(_result!))),
            ],
          ],
        ),
      );
}
