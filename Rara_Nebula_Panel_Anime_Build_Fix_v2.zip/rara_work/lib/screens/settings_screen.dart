import 'package:flutter/material.dart';
import '../main.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _theme = 'Nebula Ungu Gelap';
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Tema & Musik')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Pilih Tema',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _theme,
              decoration: const InputDecoration(labelText: 'Tema aplikasi'),
              items: const [
                DropdownMenuItem(value: 'Nebula Ungu Gelap', child: Text('🌌 Nebula Ungu Gelap')),
                DropdownMenuItem(value: 'Horror Merah', child: Text('🩸 Horror Merah Hitam')),
                DropdownMenuItem(value: 'Rose Aesthetic', child: Text('🎀 Rose Aesthetic')),
              ],
              onChanged: (v) => setState(() => _theme = v ?? 'Nebula Ungu Gelap'),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () {
                // Theme selection is saved as local state in this prototype.
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Tema $_theme dipilih. Tema dinamis penuh dapat ditambahkan berikutnya.')),
                );
              },
              child: const Text('Terapkan Tema'),
            ),
            const SizedBox(height: 24),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.music_note, size: 32, color: Color(0xFFE0B7FF)),
                    SizedBox(height: 8),
                    Text('Musik khusus Owner',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    SizedBox(height: 8),
                    Text('Kontrol musik perlu sesi Owner terverifikasi dan pemutar audio yang ditambahkan. Jangan mengandalkan tombol UI saja; backend harus memverifikasi izin untuk semua tindakan sensitif.'),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
}
