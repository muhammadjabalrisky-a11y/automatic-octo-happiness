import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// All privileged actions go through the backend. Never put Pterodactyl
/// Application API keys in this Flutter app.
class ApiClient {
  ApiClient({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  String? _token;

  void setToken(String? token) => _token = token;

  Uri _uri(String path) {
    if (!AppConfig.isConfigured) {
      throw ApiException(
        'Backend belum dikonfigurasi. Set API_BASE_URL ke URL HTTPS backend Anda.',
      );
    }
    final base = AppConfig.apiBaseUrl.replaceFirst(RegExp(r'/+$'), '');
    return Uri.parse('$base/api$path');
  }

  Future<Map<String, dynamic>> _post(
    String path,
    Map<String, dynamic> body,
  ) async {
    final uri = _uri(path);
    late final http.Response response;
    try {
      response = await _client
          .post(
            uri,
            headers: {
              'Content-Type': 'application/json',
              if (_token != null) 'Authorization': 'Bearer $_token',
            },
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 20));
    } on SocketException {
      throw ApiException('Tidak dapat terhubung. Periksa internet dan status backend.');
    } on HttpException {
      throw ApiException('Koneksi HTTP gagal. Periksa URL backend.');
    } on FormatException {
      throw ApiException('Format URL backend tidak valid.');
    } catch (e) {
      if (e is ApiException) rethrow;
      if (e.toString().contains('TimeoutException')) {
        throw ApiException('Backend terlalu lama merespons. Coba lagi sebentar.');
      }
      rethrow;
    }

    Map<String, dynamic> data;
    try {
      data = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw ApiException('Backend mengembalikan respons yang tidak valid.');
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiException(
        data['error'] as String? ?? 'Permintaan gagal (${response.statusCode}).',
      );
    }
    return data;
  }

  Future<Map<String, dynamic>> login(String username, String password) =>
      _post('/auth/login', {'username': username, 'password': password});

  Future<Map<String, dynamic>> createPanel({
    required int server,
    required String username,
    required String email,
    required String memory,
  }) =>
      _post('/panels', {
        'server': server,
        'username': username,
        'email': email,
        'memory': memory,
      });

  Future<Map<String, dynamic>> createAdmin({
    required int server,
    required String username,
    required String email,
    required String password,
  }) =>
      _post('/admin-users', {
        'server': server,
        'username': username,
        'email': email,
        'password': password,
      });

  Future<Map<String, dynamic>> createAccount({
    required String username,
    required String password,
    required String role,
  }) =>
      _post('/accounts', {
        'username': username,
        'password': password,
        'role': role,
      });
}
