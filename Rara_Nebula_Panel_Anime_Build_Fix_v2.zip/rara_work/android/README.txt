Jalankan `flutter create . --platforms=android` dari root proyek Flutter untuk menghasilkan file platform Android resmi sebelum build.
