# Rara Nebula Panel — Flutter + Backend

Paket sumber Flutter bertema nebula ungu gelap beserta backend Node.js untuk menghubungkan aplikasi ke Pterodactyl. **Ini belum APK terkompilasi.** APK belum dapat diklaim berhasil sebelum workflow build benar-benar selesai hijau; API/login juga belum bisa diuji sampai backend HTTPS dan kredensial Pterodactyl yang valid disiapkan.

## Update perbaikan & ikon anime
- Ikon launcher anime pink untuk Rara Nebula Panel disertakan di `assets/rara_anime_icon.png`.
- Konfigurasi `flutter_launcher_icons` ditambahkan; jalankan `dart run flutter_launcher_icons` setelah `flutter pub get` untuk membuat ikon Android.
- ZIP ini tetap berupa source code, bukan APK teruji. Build service harus menggunakan Flutter embedding v2 dan membuat proyek Android modern.

## Yang sudah disiapkan
- UI Flutter: beranda, login, create panel (RAM 1–10 GB/UNLI), create user Pterodactyl, manajemen akun/role, pengaturan.
- Backend Node.js dengan login JWT 12 jam, hash password bcrypt, pembatasan percobaan login, validasi input, audit log, role check di server.
- Pterodactyl API keys disimpan di backend, bukan di APK.
- Backend memberi pesan yang jelas jika konfigurasi server belum lengkap atau Pterodactyl menolak request.

## Wajib sebelum build yang benar-benar bisa login
Aplikasi memerlukan backend yang sudah online melalui HTTPS. API key Pterodactyl, ID egg, location, dan allocation berbeda untuk tiap instalasi, sehingga tidak aman atau benar untuk mengarangnya. Setelah backend terpasang dan diuji, build Flutter dengan URL backend HTTPS yang sebenarnya.

### 1. Deploy backend
1. Unggah folder `backend` ke hosting Node.js yang mendukung Node 20+ dan penyimpanan file persisten.
2. Jalankan `npm install`.
3. Salin `.env.example` menjadi `.env` atau isi variabel yang sama melalui panel Environment/Secrets hosting.
4. Atur `JWT_SECRET` dengan nilai acak panjang minimal 32 karakter, `OWNER_USERNAME`, dan `OWNER_PASSWORD` unik minimal 12 karakter.
5. Untuk setiap server yang digunakan (1–5), isi URL HTTPS panel, Application API key `ptla_...`, `PTERO_LOCATION_ID_n`, `PTERO_EGG_ID_n`, `PTERO_ALLOCATION_ID_n`, image Docker, startup, dan JSON environment yang cocok dengan egg tersebut.
6. Jalankan `npm start`, lalu buka `https://alamat-backend-anda/health`. Hasil sehat: `{"ok":true,...}`.
7. Jangan gunakan key client `ptlc_...`; backend membutuhkan Application API key dengan izin minimal yang diperlukan. Jangan commit `.env` ke repositori.

**Penting:** API Pterodactyl membutuhkan ID Location, Egg, dan Allocation yang benar. Ambil dari instalasi Anda; nilai contoh di `.env.example` hanyalah placeholder. Pastikan lokasi/allocation sesuai dan egg mendukung Docker image, startup, serta environment yang Anda isi. Fitur Create Admin di aplikasi membuat akun pengguna Pterodactyl, bukan superadmin global.

### 2. Build APK dari HP Android
Cara yang paling mudah dari HP Android jika memakai GitHub: unggah isi folder `rara_work` ke repositori, buka tab **Actions**, pilih **Build Rara Nebula APK**, lalu tekan **Run workflow**. Tunggu sampai workflow hijau, buka hasil run, lalu unduh artifact **Rara-Nebula-Panel-APK**. Untuk login API sungguhan, tambahkan repository secret bernama `API_BASE_URL` berisi URL HTTPS backend yang sudah online. Jika ingin build manual di terminal cloud yang memiliki Flutter stable + Android SDK, jalankan:

```bash
flutter create . --platforms=android --org com.raratech
flutter pub get
dart run flutter_launcher_icons
flutter pub get
flutter analyze
flutter build apk --release --dart-define=API_BASE_URL=https://API-HTTPS-ANDA
```

Ganti `https://API-HTTPS-ANDA` dengan URL backend Anda, tanpa garis miring terakhir. APK jika build sukses berada di:

`build/app/outputs/flutter-apk/app-release.apk`

Jika build error, jangan abaikan. Periksa output `flutter analyze` dan log build; dependency/versi Flutter bisa berubah. Folder `android` awalnya hanya berisi petunjuk, bukan proyek Android Gradle lengkap. Workflow `.github/workflows/build-apk.yml` sekarang membuat platform Android modern (embedding v2) sebelum build, menghasilkan ikon anime, menjalankan `flutter analyze`, lalu mengunggah APK sebagai artifact jika semua langkah sukses. Ini mengatasi akar masalah log sebelumnya: `Build failed due to use of deleted Android v1 embedding` yang muncul karena platform Android modern belum digenerate. Workflow juga menghindari error `gradlew` tidak ditemukan dengan membuat folder Android sebelum kompilasi.

## Catatan keamanan dan batasan
- Jangan masukkan PLTA/PLTC atau JWT secret ke kode Flutter atau APK.
- Simpan folder `backend/data` di disk persisten; filesystem hosting sementara bisa menghapus akun.
- Backup `backend/data/db.json` dengan aman. File JSON cocok untuk penggunaan kecil/single instance, bukan beberapa instance backend bersamaan.
- Ganti kredensial owner awal bila pernah dibagikan. Jangan gunakan password contoh.
- Tes endpoint `/health`, login owner, lalu satu operasi pada server uji sebelum memakai produksi.
- Build belum diverifikasi dengan Flutter/Android SDK di lingkungan ini karena Flutter SDK tidak tersedia. Karena itu, saya tidak mengklaim APK sudah berhasil dikompilasi.
