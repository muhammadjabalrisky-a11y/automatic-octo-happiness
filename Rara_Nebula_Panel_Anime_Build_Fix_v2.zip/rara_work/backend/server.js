'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || '';
const DATA_FILE = path.resolve(process.env.DATA_FILE || './data/db.json');
const roles = ['Reseller Panel', 'Partner Panel', 'Admin Panel', 'TK Panel', 'CEO Panel', 'Tahta Role Panel', 'Owner Panel'];
const roleLevel = Object.fromEntries(roles.map((r, i) => [r, i]));

if (process.env.NODE_ENV === 'production' && JWT_SECRET.length < 32) {
  console.error('FATAL: JWT_SECRET harus diisi dengan string acak minimal 32 karakter.');
  process.exit(1);
}
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET belum dikonfigurasi. Salin .env.example menjadi .env dan atur secrets.');
  process.exit(1);
}

app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: false })); // Native app does not need browser CORS; add a strict allowlist if a web client is added.
app.use(express.json({ limit: '32kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false }));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false }));

function ensureDb() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({ users: [], audit: [] }, null, 2), { mode: 0o600 });
  try {
    const db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (!Array.isArray(db.users) || !Array.isArray(db.audit)) throw new Error('bad schema');
    return db;
  } catch (_) { throw new Error('Database JSON rusak. Hentikan server dan pulihkan data/db.json yang valid.'); }
}
function saveDb(db) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DATA_FILE);
}
function audit(db, actor, action, details = {}) {
  db.audit.push({ at: new Date().toISOString(), actor, action, details });
  if (db.audit.length > 2000) db.audit = db.audit.slice(-2000);
}
function fail(res, status, error) { return res.status(status).json({ error }); }
function safeText(v, max = 80) { return typeof v === 'string' ? v.trim().slice(0, max) : ''; }
function auth(req, res, next) {
  const raw = req.headers.authorization || '';
  const token = raw.startsWith('Bearer ') ? raw.slice(7) : '';
  try {
    if (!token) return fail(res, 401, 'Silakan login terlebih dahulu.');
    req.session = jwt.verify(token, JWT_SECRET, { issuer: 'rara-nebula' });
    const db = ensureDb();
    const user = db.users.find(u => u.id === req.session.sub && u.active !== false);
    if (!user) return fail(res, 401, 'Sesi tidak berlaku atau akun dinonaktifkan.');
    req.currentUser = user;
    next();
  } catch (_) { return fail(res, 401, 'Sesi kedaluwarsa atau tidak valid. Login kembali.'); }
}
function allowRoles(...allowed) {
  return (req, res, next) => allowed.includes(req.currentUser.role) ? next() : fail(res, 403, 'Role akun tidak memiliki izin untuk tindakan ini.');
}
function pteroConfig(server) {
  const suffix = String(server);
  const cfg = {
    url: process.env[`PTERO_URL_${suffix}`], key: process.env[`PTERO_APP_KEY_${suffix}`],
    location: process.env[`PTERO_LOCATION_ID_${suffix}`], egg: process.env[`PTERO_EGG_ID_${suffix}`],
    allocation: process.env[`PTERO_ALLOCATION_ID_${suffix}`], image: process.env[`PTERO_DOCKER_IMAGE_${suffix}`],
    startup: process.env[`PTERO_STARTUP_${suffix}`] || 'npm start', env: process.env[`PTERO_ENV_JSON_${suffix}`] || '{}'
  };
  if (!cfg.url || !cfg.key || !cfg.location || !cfg.egg || !cfg.allocation || !cfg.image) return null;
  try { const u = new URL(cfg.url); if (u.protocol !== 'https:') return null; cfg.url = u.origin; cfg.environment = JSON.parse(cfg.env); }
  catch (_) { return null; }
  return cfg;
}
async function pteroRequest(cfg, endpoint, method, body) {
  const response = await fetch(`${cfg.url}/api/application/${endpoint}`, {
    method, headers: { Authorization: `Bearer ${cfg.key}`, Accept: 'Application/vnd.pterodactyl.v1+json', 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const msg = Array.isArray(data.errors) ? data.errors.map(e => e.detail || e.code).filter(Boolean).join('; ') : '';
    const err = new Error(msg || `Pterodactyl menolak permintaan (HTTP ${response.status}).`); err.status = response.status; throw err;
  }
  return data;
}

// Bootstrap initial owner only once. Never overwrite an existing owner password on restart.
async function bootstrapOwner() {
  const db = ensureDb();
  if (!db.users.length) {
    const username = safeText(process.env.OWNER_USERNAME, 40);
    const password = process.env.OWNER_PASSWORD || '';
    if (!username || password.length < 12 || password.startsWith('REPLACE_')) {
      console.error('FATAL: Atur OWNER_USERNAME dan OWNER_PASSWORD (minimal 12 karakter) sebelum bootstrap akun pertama.');
      process.exit(1);
    }
    db.users.push({ id: crypto.randomUUID(), username, passwordHash: await bcrypt.hash(password, 12), role: 'Owner Panel', active: true, createdAt: new Date().toISOString() });
    audit(db, username, 'bootstrap_owner'); saveDb(db);
    console.log('Akun owner awal dibuat. Simpan kredensial dengan aman.');
  }
}

app.get('/health', (_req, res) => res.json({ ok: true, service: 'rara-nebula-api', time: new Date().toISOString() }));
app.post('/api/auth/login', async (req, res) => {
  const username = safeText(req.body?.username, 40);
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (!username || !password || password.length > 200) return fail(res, 400, 'Username dan password wajib diisi.');
  const db = ensureDb();
  const user = db.users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.active !== false);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return fail(res, 401, 'Username atau password salah.');
  const token = jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET, { expiresIn: '12h', issuer: 'rara-nebula' });
  audit(db, user.username, 'login'); saveDb(db);
  res.json({ token, user: { username: user.username, role: user.role } });
});

app.post('/api/accounts', auth, allowRoles('Owner Panel'), async (req, res) => {
  const username = safeText(req.body?.username, 40);
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  const role = safeText(req.body?.role, 40);
  if (!/^[a-zA-Z0-9_.-]{3,40}$/.test(username)) return fail(res, 400, 'Username hanya boleh huruf, angka, titik, garis bawah, atau minus (3–40 karakter).');
  if (password.length < 12 || password.length > 200) return fail(res, 400, 'Password harus 12–200 karakter.');
  if (!(role in roleLevel) || role === 'Owner Panel') return fail(res, 400, 'Role tidak valid. Owner baru tidak dapat dibuat melalui aplikasi.');
  const db = ensureDb();
  if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase())) return fail(res, 409, 'Username sudah digunakan.');
  const user = { id: crypto.randomUUID(), username, passwordHash: await bcrypt.hash(password, 12), role, active: true, createdAt: new Date().toISOString() };
  db.users.push(user); audit(db, req.currentUser.username, 'create_account', { username, role }); saveDb(db);
  res.status(201).json({ ok: true, user: { username, role }, message: 'Akun berhasil dibuat.' });
});

async function createPteroUser(cfg, username, email, password) {
  const result = await pteroRequest(cfg, 'users', 'POST', { username, email, first_name: username, last_name: 'Rara', password });
  return result.attributes;
}
app.post('/api/admin-users', auth, allowRoles('Owner Panel'), async (req, res) => {
  const server = Number(req.body?.server), username = safeText(req.body?.username, 40), email = safeText(req.body?.email, 120).toLowerCase();
  const password = typeof req.body?.password === 'string' ? req.body.password : '';
  if (!Number.isInteger(server) || server < 1 || server > 5) return fail(res, 400, 'Nomor server harus 1 sampai 5.');
  if (!/^[a-zA-Z0-9_.-]{3,40}$/.test(username) || !/^\S+@\S+\.\S+$/.test(email) || password.length < 12) return fail(res, 400, 'Username/email tidak valid atau password kurang dari 12 karakter.');
  const cfg = pteroConfig(server); if (!cfg) return fail(res, 503, `Konfigurasi Pterodactyl Server ${server} belum lengkap atau bukan HTTPS.`);
  try {
    const user = await createPteroUser(cfg, username, email, password);
    const db = ensureDb(); audit(db, req.currentUser.username, 'create_ptero_user', { server, username, userId: user.id }); saveDb(db);
    res.status(201).json({ ok: true, server, user: { id: user.id, username: user.username, email: user.email }, message: 'Akun pengguna Pterodactyl dibuat. Ini bukan superadmin global panel.' });
  } catch (e) { res.status(e.status === 422 ? 409 : 502).json({ error: `Gagal membuat akun Pterodactyl: ${e.message}` }); }
});
app.post('/api/panels', auth, async (req, res) => {
  const server = Number(req.body?.server), username = safeText(req.body?.username, 40), email = safeText(req.body?.email, 120).toLowerCase();
  const rawMemory = req.body?.memory;
  if (!Number.isInteger(server) || server < 1 || server > 5) return fail(res, 400, 'Nomor server harus 1 sampai 5.');
  if (!/^[a-zA-Z0-9_.-]{3,40}$/.test(username) || !/^\S+@\S+\.\S+$/.test(email)) return fail(res, 400, 'Username atau email tidak valid.');
  const memory = rawMemory === 'unli' ? 0 : Number(rawMemory);
  if (rawMemory !== 'unli' && (!Number.isInteger(memory) || memory < 1024 || memory > 10240 || memory % 1024 !== 0)) return fail(res, 400, 'RAM harus 1–10 GB atau UNLI sesuai kuota server.');
  if (req.currentUser.role !== 'Owner Panel' && req.currentUser.role !== 'CEO Panel' && req.currentUser.role !== 'Admin Panel' && req.currentUser.role !== 'TK Panel' && req.currentUser.role !== 'Partner Panel' && req.currentUser.role !== 'Reseller Panel') return fail(res, 403, 'Role tidak diizinkan membuat panel.');
  const cfg = pteroConfig(server); if (!cfg) return fail(res, 503, `Konfigurasi Pterodactyl Server ${server} belum lengkap atau bukan HTTPS.`);
  try {
    const tempPassword = crypto.randomBytes(18).toString('base64url');
    const user = await createPteroUser(cfg, username, email, tempPassword);
    const environment = { ...cfg.environment };
    const payload = { name: `${username}-rara`, user: user.id, egg: Number(cfg.egg), docker_image: cfg.image, startup: cfg.startup,
      environment, limits: { memory, swap: 0, disk: memory === 0 ? 0 : Math.max(memory, 1024), io: 500, cpu: 100 },
      feature_limits: { databases: 1, backups: 1, allocations: 1 }, deploy: { locations: [Number(cfg.location)], dedicated_ip: false, port_range: [] },
      allocation: { default: Number(cfg.allocation) } };
    const created = await pteroRequest(cfg, 'servers', 'POST', payload);
    const db = ensureDb(); audit(db, req.currentUser.username, 'create_panel', { server, username, panelId: created.attributes?.id }); saveDb(db);
    res.status(201).json({ ok: true, server, panel: { id: created.attributes?.id, name: created.attributes?.name, identifier: created.attributes?.identifier }, user: { id: user.id, username: user.username }, temporaryPassword: tempPassword, message: 'Server dibuat. Simpan password sementara ini sekarang; password tidak akan ditampilkan lagi.' });
  } catch (e) { res.status(e.status === 422 ? 400 : 502).json({ error: `Gagal membuat panel: ${e.message}` }); }
});

app.use((err, _req, res, _next) => {
  console.error('Request error:', err.message);
  res.status(500).json({ error: 'Terjadi kesalahan server. Periksa log backend.' });
});
bootstrapOwner().then(() => {
  app.listen(PORT, () => console.log(`Rara Nebula API listening on port ${PORT}`));
}).catch((err) => {
  console.error('FATAL saat inisialisasi database:', err.message);
  process.exit(1);
});
